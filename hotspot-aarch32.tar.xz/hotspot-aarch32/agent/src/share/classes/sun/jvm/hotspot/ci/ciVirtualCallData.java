/*
 * Copyright (c) 2011, 2012, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 *
 */

package sun.jvm.hotspot.ci;

import java.io.*;
import java.util.*;
import sun.jvm.hotspot.debugger.*;
import sun.jvm.hotspot.runtime.*;
import sun.jvm.hotspot.oops.*;
import sun.jvm.hotspot.types.*;

public class ciVirtualCallData extends VirtualCallData {
  public ciVirtualCallData(DataLayout data) {
    super(data);
  }

  public Klass receiver(int row) {
      throw new InternalError("should not call");
  }

  public ciKlass receiverAt(int row) {
    //assert((uint)row < rowLimit(), "oob");
    ciMetadata recv = ciObjectFactory.getMetadata(addressAt(receiverCellIndex(row)));
    if (recv != null && !(recv instanceof ciKlass)) {
      System.err.println(recv);
    }
    //assert(recv == NULL || recv->isKlass(), "wrong type");
    return (ciKlass)recv;
  }
}
